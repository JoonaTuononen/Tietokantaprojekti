CREATE DATABASE  IF NOT EXISTS `autokauppa` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `autokauppa`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: autokauppa
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autot`
--

DROP TABLE IF EXISTS `autot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autot` (
  `AutoID` int NOT NULL AUTO_INCREMENT,
  `Merkki` varchar(255) DEFAULT NULL,
  `Malli` varchar(255) DEFAULT NULL,
  `Rekisterinumero` varchar(20) DEFAULT NULL,
  `ToimipisteID` int DEFAULT NULL,
  PRIMARY KEY (`AutoID`),
  KEY `FK_Toimipiste_Autot` (`ToimipisteID`),
  CONSTRAINT `FK_Toimipiste_Autot` FOREIGN KEY (`ToimipisteID`) REFERENCES `toimipisteet` (`ToimipisteID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autot`
--

LOCK TABLES `autot` WRITE;
/*!40000 ALTER TABLE `autot` DISABLE KEYS */;
INSERT INTO `autot` VALUES (1,'Volkswagen','Golf','XBF-644',1),(2,'Toyota','Corolla','ABC-123',2),(3,'Ford','Fiesta','DEF-456',3),(4,'Honda','Civic','GHI-789',1),(5,'Nissan','Micra','JKL-012',2),(6,'Mercedes-Benz','A-Class','MNO-345',3),(7,'BMW','3 Series','PQR-678',1),(8,'Audi','A4','STU-901',2),(9,'Hyundai','i30','VWX-234',3),(10,'Kia','Rio','YZA-567',1),(11,'Volvo','V40','BCD-890',2),(12,'Peugeot','208','EFG-123',3),(13,'Renault','Clio','HIJ-456',1),(14,'Subaru','Impreza','KLM-789',2),(15,'Mazda','3','OPQ-012',3),(16,'Skoda','Octavia','RST-345',1),(17,'Seat','Leon','UVW-678',2),(18,'Fiat','500','XYZ-901',3),(19,'Citroen','C3','BCD-234',1),(20,'Mini','Cooper','EFG-567',2),(21,'Dacia','Sandero','HIJ-890',3),(22,'Alfa Romeo','Giulietta','KLM-123',1),(23,'Lexus','CT','OPQ-456',2),(24,'Suzuki','Swift','RST-789',3),(25,'Smart','Fortwo','UVW-012',1),(26,'Tesla','Model 3','XYZ-345',2),(27,'Jeep','Renegade','BCD-678',3),(28,'Land Rover','Discovery','EFG-901',1),(29,'Porsche','Macan','HIJ-234',2),(30,'Mitsubishi','Outlander','KLM-567',3);
/*!40000 ALTER TABLE `autot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-04 16:30:52
